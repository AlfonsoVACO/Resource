
-- Inicializamos la BD

INSERT INTO Usuario (username, password) VALUES ('admin', '$2a$10$XURPShQNCsLjp1ESc2laoObo9QZDhxz73hJPaEv7/cBha4pk0AgP.');