package com.mycompany.foreach.models.seguridad;

public class ResponseTO {

	private String codigo;
	private String mensaje;
	private String folio;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigoOperacion) {
		this.codigo = codigoOperacion;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String descripcion) {
		this.mensaje = descripcion;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	@Override
	public String toString() {
		return "{codigo=" + codigo + ", mensaje=" + mensaje + ", folio=" + folio + "}";
	}
}
