package com.mycompany.foreach.exceptions;

import java.util.List;

public class ValidacionException extends RuntimeException {
	private static final long serialVersionUID = 6830965595828586675L;

	private List<String> erroresRequest;

	public ValidacionException(List<String> erroresRequest) {
		this.setErroresRequest(erroresRequest);
	}

	public List<String> getErroresRequest() {
		return erroresRequest;
	}

	public void setErroresRequest(List<String> erroresRequest) {
		this.erroresRequest = erroresRequest;
	}
}
