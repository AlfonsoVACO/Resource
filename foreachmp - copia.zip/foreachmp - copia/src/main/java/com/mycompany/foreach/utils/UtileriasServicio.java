package com.mycompany.foreach.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UtileriasServicio {
	private static Logger log = LoggerFactory.getLogger(UtileriasServicio.class);

	private UtileriasServicio() {

	}

	public static String objetoAJson(Object object) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			log.info("Incidencia al parsear el Objecto a Json...");
			throw new RuntimeException(e);
		}
	}
	
	public static <T> T jsonAObjeto(String resultado, Class<T> objeto) {
		try{
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(resultado, objeto);
		} catch (Exception e) {
			log.info( "Incidencia al parsear la respuesta JSON al Objecto...");
			throw new RuntimeException(e);
		}
	}
}
