package com.mycompany.foreach.models.seguridad;

public class SeguridadResponse {
	private SeguridadRespuestaTO resultado;

	public SeguridadRespuestaTO getResultado() {
		return resultado;
	}

	public void setResultado(SeguridadRespuestaTO resultado) {
		this.resultado = resultado;
	}
}
