package com.mycompany.foreach.models;

public class CurpRequestTO {
	private String curp;

	public String getCurp() {
		return curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

}
