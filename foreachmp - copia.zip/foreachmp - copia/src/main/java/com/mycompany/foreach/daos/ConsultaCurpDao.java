package com.mycompany.foreach.daos;

import java.util.HashMap;

import com.mycompany.foreach.utils.HttpUtils;

public class ConsultaCurpDao {
	private static final String TOKEN_BEARER = "Bearer ";

	public String ejecutaServicio360(Object curp) {
		HttpUtils utilhttp = new HttpUtils("https://10.50.108.59:443/lorien/consulta/datos-renapo/curp/1");
		return utilhttp.simpleSerice(new HashMap<String, String>(), curp, "POST", "application/json");
	}
}
