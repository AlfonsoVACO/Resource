package com.mycompany.foreach.controllers;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.mycompany.foreach.utils.FxDialogs;
import com.mycompany.foreach.utils.actions.Walking;
import com.mycompany.foreach.utils.constantes.Constantes;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

public class ReadLogController implements Initializable {

	@FXML
	private TextField fileLog;
	@FXML
	private TextArea content;
	@FXML
	private Button btnCreateFile;

	private boolean[] radios = new boolean[3];

	private List<String> logEncontrado;

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		btnCreateFile.setVisible(false);
		logEncontrado = new ArrayList<>();
	}

	@FXML
	private void clean(ActionEvent event) {
		this.fileLog.setText("");
		this.content.setText("");
		btnCreateFile.setVisible(false);
	}

	@FXML
	private void createFile(ActionEvent event) throws IOException {
		FileChooser choser = new FileChooser();
		choser.setTitle("Guarda Log");
		choser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Todos los archivos", "*.*"));
		File saveFile = choser.showSaveDialog(null);
		try (BufferedWriter bufferedwritter = new BufferedWriter(new FileWriter(saveFile))) {
			logEncontrado.forEach(it -> {
				try {
					bufferedwritter.write(it, 0, it.length());
					bufferedwritter.newLine();
				} catch (IOException e) {
					FxDialogs.showError("Error", e.getMessage());
				}
			});
		}
		FxDialogs.showInformation("Listo", "Archivo creado");
	}

	@FXML
	private void avanzado(ActionEvent event) {
		this.radios = FxDialogs.getRadioDes(Constantes.TITLE, "Opciones avanzadas",
				new RadioButton("Mayusculas y minusculas"), new RadioButton("Solo minusculas"),
				new RadioButton("Solo mayusculas"));
	}

	@FXML
	private void examinar(ActionEvent event) {
		btnCreateFile.setVisible(false);
		FileChooser choser = new FileChooser();
		choser.setTitle("Agregar path");
		File archivo = choser.showOpenDialog(null);
		if (archivo != null) {
			if (!notTrue())
				this.radios[0] = true;
			this.fileLog.setText(archivo.getPath());
			String palabra = FxDialogs.showTextInput("Agrega palabra", "Ingresa la palabra a agregar", "");
			if (palabra != null && !palabra.isEmpty()) {
				Walking walking = new Walking();
				logEncontrado = walking.getDetallesFindCadena(palabra, archivo, this.radios);
				StringBuilder stringbuilder = new StringBuilder();
				content.setText(getBody(logEncontrado, stringbuilder).toString());
				btnCreateFile.setVisible(true);
			}
		}
	}

	private StringBuilder getBody(List<String> parrafo, StringBuilder stringbuilder) {
		parrafo.forEach(it -> stringbuilder.append(it).append("\n"));
		return stringbuilder;
	}

	private boolean notTrue() {
		for (boolean item : this.radios) {
			if (item)
				return true;
		}
		return false;
	}
}
