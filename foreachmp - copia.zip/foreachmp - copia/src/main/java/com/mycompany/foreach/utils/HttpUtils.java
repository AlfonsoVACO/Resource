package com.mycompany.foreach.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

public class HttpUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtils.class);
	private String url;
	private String xaplicacion;
	private static final String MEDIATYPE = "application/json";
	private static final String XAPLICATION = "X-Aplicacion";
	private static final String AUTHORIZATION = "Authorization";
	private static final String BEARER = "Bearer ";
	private static final String FAILPETICIONCODE = "Petición fallida : Código de error: ";
	private static final String FAILPETICION = "Petición fallida";
	private static final String ERRORCODE = "Código de error: ";
	private static final String STRINGERROR = "Error";

	public HttpUtils(String url, String xaplicacion) {
		this.url = url;
		this.xaplicacion = xaplicacion;
	}

	public HttpUtils(String url) {
		this.url = url;
	}

	public String ejecutar() {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(this.url);
			webResource.header("Content-Length", 348);
			webResource.header(XAPLICATION, this.xaplicacion);
			webResource.header(AUTHORIZATION, BEARER + GeneraToken.actionPerformed());
			webResource.type(MEDIATYPE);
			ClientResponse response = webResource.post(ClientResponse.class);
			if (response.getStatus() != 201) {
				FxDialogs.showError(FAILPETICION, ERRORCODE + response.getStatus());
				throw new RuntimeException(FAILPETICIONCODE + response.getStatus());
			}
			return response.getEntity(String.class);
		} catch (Exception e) {
			FxDialogs.showException(STRINGERROR, e.getMessage(), e);
			throw new RuntimeException(e.getMessage());
		}
	}

	public String ejecutar(Object object) {
		return generic(new HashMap<>(), object, "POST", MEDIATYPE);
	}

	public String ejecutarPOST(Map<String, String> headers, Object object) {
		return generic(headers, object, "POST", MEDIATYPE);
	}

	public String ejecutarMetodo(Map<String, String> headers, Object object, String method) {
		return generic(headers, object, method, MEDIATYPE);
	}

	public String ejecutarMetodo(Map<String, String> headers, Object object, String method, String media) {
		return generic(headers, object, method, media);
	}

	private String generic(Map<String, String> headers, Object object, String method, String media) {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(this.url);
			headers.forEach((key, value) -> webResource.header(key, value));
			webResource.header(XAPLICATION, this.xaplicacion);
			webResource.header(AUTHORIZATION, BEARER + GeneraToken.actionPerformed());
			webResource.type(media);
			ClientResponse response = webResource.method(method, ClientResponse.class, object);
			if (response.getStatus() != 201) {
				FxDialogs.showError(FAILPETICION, ERRORCODE + response.getStatus());
				throw new RuntimeException(FAILPETICIONCODE + response.getStatus());
			}
			return response.getEntity(String.class);
		} catch (Exception e) {
			FxDialogs.showException(STRINGERROR, e.getMessage(), e);
			throw new RuntimeException(e.getMessage());
		}
	}

	public String simpleSerice(Map<String, String> headers, Object object, String method, String media) {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(this.url);
			headers.forEach((key, value) -> webResource.header(key, value));
			webResource.header(AUTHORIZATION, BEARER + GeneraToken.actionPerformed());
			webResource.type(media);
			ClientResponse response = webResource.method(method, ClientResponse.class, object);
			if (response.getStatus() != 201) {
				FxDialogs.showError(FAILPETICION, ERRORCODE + response.getStatus());
				throw new RuntimeException(FAILPETICIONCODE + response.getStatus());
			}
			return response.getEntity(String.class);
		} catch (Exception e) {
			FxDialogs.showException(STRINGERROR, e.getMessage(), e);
			throw new RuntimeException(e.getMessage());
		}
	}

	@SuppressWarnings("deprecation")
	public String examplePost() throws NoSuchAlgorithmException, KeyManagementException {
		final ClientConfig config = new DefaultClientConfig();
		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(
				SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER, SSLUtil.getInsecureSSLContext()));
		final Client client = Client.create(config);
		final WebResource webResource = client.resource(this.url);
		LOGGER.info("Bytes: {}", "".getBytes());
		webResource.header("Content-Length", "".getBytes());
		webResource.header(XAPLICATION, this.xaplicacion);
		webResource.header(AUTHORIZATION, BEARER + GeneraToken.actionPerformed());
		final ClientResponse response = webResource.type(MEDIATYPE).post(ClientResponse.class);
		final String result = getStringFromInputStream(response.getEntityInputStream());

		LOGGER.info("INFO >>> Response from API was: {}", result);
		client.destroy();
		return result;

	}

	private String getStringFromInputStream(InputStream is) {
		final StringBuilder sb = new StringBuilder("");
		String line;
		try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}
		return sb.toString();
	}

	private static class SSLUtil {
		protected static SSLContext getInsecureSSLContext() throws KeyManagementException, NoSuchAlgorithmException {
			final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(final java.security.cert.X509Certificate[] arg0, final String arg1)
						throws CertificateException {
				}

				@Override
				public void checkServerTrusted(final java.security.cert.X509Certificate[] arg0, final String arg1)
						throws CertificateException {
				}

			} };

			final SSLContext sslcontext = SSLContext.getInstance("TLSv1.2");
			sslcontext.init(null, trustAllCerts, new java.security.SecureRandom());
			return sslcontext;
		}
	}
}
