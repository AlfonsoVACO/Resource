package com.mycompany.foreach.exceptions;

public class MessageException extends RuntimeException {
	private static final long serialVersionUID = 7585550831554109157L;

	private Integer codeError;
	private String customMessage;

	public MessageException(Integer code) {
		codeError = code;
	}

	public MessageException(Integer code, String mensajeExtra) {
		codeError = code;
		customMessage = mensajeExtra;
	}

	public MessageException(Integer code, Throwable cause) {
		super(cause);
		codeError = code;
	}

	public MessageException(Integer code, String mensajeExtra, Throwable cause) {
		super(cause);
		codeError = code;
		customMessage = mensajeExtra;
	}

	public MessageException(Integer codeError, Exception exception) {
		super(exception);
		this.codeError = codeError;
	}

	public Integer getCodeError() {
		return codeError;
	}

	public void setCodeError(Integer codeError) {
		this.codeError = codeError;
	}

	public String getCustomMessage() {
		return customMessage;
	}

	public void setCustomMessage(String customMessage) {
		this.customMessage = customMessage;
	}
}
