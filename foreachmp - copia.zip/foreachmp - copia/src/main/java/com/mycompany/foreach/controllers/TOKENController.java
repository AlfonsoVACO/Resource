package com.mycompany.foreach.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import com.mycompany.foreach.utils.FxDialogs;
import com.mycompany.foreach.utils.GeneraToken;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;

public class TOKENController implements Initializable {
	@FXML
	private Label panelToken;
	private final Clipboard clipboard = Clipboard.getSystemClipboard();
	private final ClipboardContent content = new ClipboardContent();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//
	}

	@FXML
	private void ejecutar(ActionEvent event) {
		this.panelToken.setText("");
		String tokenGenerated = GeneraToken.actionPerformed();
		if (tokenGenerated != null && !tokenGenerated.isEmpty()) {
			this.panelToken.setText(tokenGenerated);
			content.putString(tokenGenerated);
			clipboard.setContent(content);
		} else {
			FxDialogs.showError("TOKEN", "No se pudo generar token");
		}
	}
}
