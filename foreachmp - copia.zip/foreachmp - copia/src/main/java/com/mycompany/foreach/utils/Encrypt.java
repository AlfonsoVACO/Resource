package com.mycompany.foreach.utils;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Encrypt <T>{
	public static final Logger LOGGER = LoggerFactory.getLogger(Encrypt.class);
	private static final String RESPONSE = "response";
	private Map<String, Object> mapaSalida;

	public Encrypt() {
		this.mapaSalida = new HashMap<>();
	}

	public Map<String, Object> get(T objeto, String seguridad) {
		String json = UtileriasServicio.objetoAJson(objeto);
		JSONObject objetoJSON = new JSONObject(json);
		Iterator<?> iterador = objetoJSON.keys();
		while (iterador.hasNext()) {
			String key = (String) iterador.next();
			if (!key.equals(RESPONSE) && !isObjectOrArray(objetoJSON.get(key))) {
				String value = getType(objetoJSON.get(key));
				String encriptado = "";
				try {
					encriptado = encrypt(value, seguridad);
				} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
						| NoSuchAlgorithmException | InvalidKeySpecException e) {
					LOGGER.error(e.getMessage());
				}
				this.mapaSalida.put(key, encriptado);
			}
		}
		JSONObject otherObject = llenarcampos((JSONObject) objetoJSON.get(RESPONSE));
		String jsonOtherObject = otherObject != null ? otherObject.toString() : "";
		this.mapaSalida.put(RESPONSE, UtileriasServicio.jsonAObjeto(jsonOtherObject, Object.class));
		return this.mapaSalida;
	}

	private String encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException,
			InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeySpecException {
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
		return Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
	}

	private PublicKey getPublicKey(String base64PublicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
		PublicKey publicKey = null;
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		publicKey = keyFactory.generatePublic(keySpec);
		return publicKey;
	}

	private String getType(Object value) {
		return !(value instanceof String) ? String.valueOf(value) : (String) value;
	}

	private boolean isObjectOrArray(Object objeto) {
		return objeto instanceof JSONObject || objeto instanceof JSONArray;
	}

	private JSONObject llenarcampos(JSONObject objetoJSON) {
		if (objetoJSON != null) {
			Iterator<?> iterator = objetoJSON.keys();
			while (iterator.hasNext()) {
				String keyObj = (String) iterator.next();
				Object objetoChi = objetoJSON.get(keyObj);
				if (objetoChi instanceof JSONObject) {
					JSONObject objeto = llenarcampos((JSONObject) objetoChi);
					objetoJSON.put(keyObj, objeto);
				} else if (!(objetoChi instanceof JSONArray)) {
					String valueOb = getType(objetoJSON.get(keyObj));
					String sinSharp = valueOb.substring(1, valueOb.length());
					if (this.mapaSalida.containsKey(sinSharp)) {
						objetoJSON.put(keyObj, this.mapaSalida.get(sinSharp));
					}
				}
			}
		}
		return objetoJSON;
	}
}
