package com.mycompany.foreach.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.mycompany.foreach.annotation.CampoOpcional;
import com.mycompany.foreach.annotation.Obligatorios;
import com.mycompany.foreach.exceptions.MessageException;
import com.mycompany.foreach.exceptions.ValidacionException;

import javafx.scene.control.TextInputControl;

public class UtilValidacion {
	private Object objeto;
	private String[] exclude;
	private boolean isOpcional;

	public UtilValidacion(Object objeto, boolean isOpcional, String... exclude) {
		this.objeto = objeto;
		this.exclude = exclude;
		this.isOpcional = isOpcional;
	}

	public void validarRequest() {
		Collection<Field> camposRequest = obtenerAtributosRequest(this.objeto);
		List<String> erroresRequest = iterarCamposRequest(camposRequest, this.objeto, this.exclude);
		if (!erroresRequest.isEmpty()) {
			FxDialogs.showLongMessage("Vacíos", "Se encontraron campos vacíos", erroresRequest);
			throw new ValidacionException(erroresRequest);
		}
	}

	private List<String> iterarCamposRequest(Collection<Field> camposRequest, Object objeto, String... exclude) {
		List<String> erroresRequest = new ArrayList<>();
		camposRequest.forEach(field -> {
			Annotation anotacionesCampo = field.getAnnotation(Obligatorios.class);
			if (anotacionesCampo != null) {
				String campoValidado = validarCampo(field, objeto, anotacionesCampo, exclude);
				if (!campoValidado.isEmpty())
					erroresRequest.add(campoValidado);
			}
		});
		return erroresRequest;
	}

	private String validarCampo(Field field, Object objeto, Annotation anotacion, String... exclude) {
		if (!Arrays.asList(exclude).contains(field.getName())) {
			Object valorCampo = null;
			field.setAccessible(true);
			try {
				valorCampo = field.get(objeto);
				if ((valorCampo instanceof String)) {
					return enviaMensajeError(valorCampo, anotacion);
				} else if (valorCampo instanceof TextInputControl) {
					return enviaMensajeError(((TextInputControl) valorCampo).getText(), anotacion);
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				throw new MessageException(1000, e.getMessage());
			}
		}
		return "";
	}

	private String enviaMensajeError(Object valorCampo, Annotation anotacion) {
		String regex = isOpcional ? ((CampoOpcional) anotacion).regex() : ((Obligatorios) anotacion).regex();
		String messajeError = isOpcional ? ((CampoOpcional) anotacion).mensajeError()
				: ((Obligatorios) anotacion).mensajeError();
		String mensajeRegex = isOpcional ? ((CampoOpcional) anotacion).mensajeErrorRegex()
				: ((Obligatorios) anotacion).mensajeErrorRegex();
		if (!isOpcional && valorCampo != null && !valorCampo.toString().trim().isEmpty()
				&& !valorCampo.toString().matches(regex)) {
			return mensajeRegex;
		} else if (!isOpcional && (valorCampo == null || valorCampo.toString().trim().isEmpty())) {
			return messajeError;
		} else {
			if (valorCampo != null && !valorCampo.toString().trim().isEmpty()
					&& !valorCampo.toString().matches(regex)) {
				return mensajeRegex;
			}
		}
		return "";
	}

	private Collection<Field> obtenerAtributosRequest(Object objeto) {
		Collection<Field> camposRequest = new ArrayList<>();
		List<Field> fields = Arrays.asList(objeto.getClass().getDeclaredFields());
		fields.addAll(Arrays.asList(objeto.getClass().getSuperclass().getDeclaredFields()));
		camposRequest.addAll(fields);
		return camposRequest;
	}
}
