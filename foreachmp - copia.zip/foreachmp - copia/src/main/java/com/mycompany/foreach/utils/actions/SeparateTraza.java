package com.mycompany.foreach.utils.actions;

public class SeparateTraza {
	private String trazaWork;

	public SeparateTraza(String trazaWork) {
		this.trazaWork = trazaWork;
	}

	public String get() {
		if (this.trazaWork.length() > 106 && this.trazaWork.contains("[core, ")) {
			String onlyFirst = this.trazaWork.substring(0, 106);
			int index = onlyFirst.indexOf("[core, ");
			String out = onlyFirst.substring(index, 77);
			String valuesRepaced = replaceValues(out.trim());
			return idTraza(valuesRepaced);
		}
		return "";
	}

	private String idTraza(String valuesRepaced) {
		String[] listValues = valuesRepaced.split(",");
		if (listValues.length > 1)
			return listValues[1];
		return "";
	}

	private String replaceValues(String out) {
		return out.replace("[", "").replace("]", "").replace(" ", "");
	}
}
