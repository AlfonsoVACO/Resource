package com.mycompany.foreach.utils;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class GeneraToken {
	
	private GeneraToken() {
		
	}
	
	public static String actionPerformed() {
	    PrivateKey privateKey = obtenerPrivateKey("MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANWhPvBjBYgkdt76PFSjCNyxmOIoSLK6lpaaai0JuJANIQnWNcB150/YjQuVpeFU8JqS8JxhZRF4ikFWVBJuHQjf8SVCGARgAcjQ1ctpeYsa84bjBm3rEogmeaqNsxLCmiQzIxaH9nknFoRmFoqUt+sjA+AUSz8fO+O0SdD8e56RAgMBAAECgYAPv14jXDlJKt70Wt/doVMC6biKW0vYmPaGzYUsIr5PKBiaYAcAU/CkKyNiijp7HMbLri88Z9WKbydJ37I81Y8gOMXDeQstXMKQMEtBYvc4OTNZH7eq1tf1i68S92KYuiaorUiqzs8Y5oI507JZDy62z2QxPjm7w1aw5GrMeDsUnQJBAPxrRAXPFrNsHKrgBbvINOdP75lnwnzkRIWKJrkgedmMbV4ntd6ZQ6Nb0kPw948usmpWCn8EMByWW2w31UdFw3cCQQDYqRscqvDAP5CMKAZQ34jx5lex3UaProj1vdPttq2krLJUrBkZLisYoKjPoV/ba4wEj+no2IUSGJBUl6+O3mA3AkAjeQeUMWglSto0gUsM+rPElg0758MDPikLA0Ex3wiAtCVih/4dDDjfKjZAagrASnW0T+cltnb0bYTnjmkgnQM9AkBpsZ1jT9TgxGGcrg3euB3TfD49q6e3gjqYP0G6zopJMmJQwiAAU7B8dCvGFoBvxzhoJVjD2ZSZLliCm/jt5nfjAkBIvIUv7N5qj2XcVwZWhIk1FnQJkeSMFchxlNUoXIrdlIOysqLDnsFFEWLczCEGrosJ6C9yyDA/m7k+06NIQRYl");
	    String subject = "EnqskLoVJmF6xOI/s7KSukhzbN55KfIf4qDaeFc6LFyjTjC2HhGYCtE1MyOD/tV1HqJ5avtNPv8R+Z+FxAXOa/6iYuajCuScChCWA9/s1Jfslh14uC9Wkm2cCfsI6pcpOEG26agorffRRjwYqcys+CgojRKdFR1c2V9MN272avXM/vRqhI72ZycSGVMiZfPwM407/AJVXlEveDB2pjASxa1WXlqhqfIp34/fk+hMwctTN1W1OIacYunS1bnvX7Sf7VFeG33ITl0Od3M+kJGwaVKMowdyvNAQZBaYjy395A1ezvJSHTtDjFbVqSRkmL5drnhLKHZewuufzox9uV5wzQ==";
	    Date date1 = new Date();
	    long t1 = date1.getTime();
	    Date expirationTime1 = new Date(t1 + 20000L);
	    return Jwts.builder()
	      .setSubject(subject)
	      .setIssuedAt(new Date())
	      .signWith(SignatureAlgorithm.RS256, privateKey)
	      .setExpiration(expirationTime1)
	      .compact();
	  }
	
	private static PrivateKey obtenerPrivateKey(String clavePrivada) {
		try {
			byte[] encoded = Base64.decodeBase64(clavePrivada);
			PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(encoded);
			KeyFactory kf = KeyFactory.getInstance("RSA");
			return kf.generatePrivate(spec);
		} catch (Exception e) {
			return null;
		}
	}
}
