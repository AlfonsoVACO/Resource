package com.mycompany.foreach.models.seguridad;

public class SeguridadRespuestaTO {
	
	private String idAcceso;
	private String accesoPublico;
	private String accesoPrivado;

	public String getIdAcceso() {
		return idAcceso;
	}

	public void setIdAcceso(String idAcceso) {
		this.idAcceso = idAcceso;
	}

	public String getAccesoPublico() {
		return accesoPublico;
	}

	public void setAccesoPublico(String accesoPublico) {
		this.accesoPublico = accesoPublico;
	}

	public String getAccesoPrivado() {
		return accesoPrivado;
	}

	public void setAccesoPrivado(String accesoPrivado) {
		this.accesoPrivado = accesoPrivado;
	}
}
