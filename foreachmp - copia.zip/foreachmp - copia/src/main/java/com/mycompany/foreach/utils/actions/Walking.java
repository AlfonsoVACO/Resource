package com.mycompany.foreach.utils.actions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.stream.Collectors;

import com.mycompany.foreach.utils.FxDialogs;

/**
 *
 * @author 6_Delta
 */
public class Walking {

	private static final String ERROR = "Error";
	private int contador = 0;

	public List<String> execute(String palabra, List<String> listaextends, Path start, boolean[] config,
			List<String> exclude) throws IOException {
		final ArrayList<String> listaencuentra = new ArrayList<>();
		Files.walkFileTree(start, new FileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
				if ((file != null) && (!file.getParent().toString().contains("System Volume Information"))) {
					if (listaextends.size() == 1 && listaextends.get(0).equals("*")
							&& verificaExcludes(file, exclude)) {
						if ((leerFichero(file, palabra, config))) {
							listaencuentra.add(file.toString());
						}
					} else {
						listaextends.forEach(it -> {
							if ((file.toString().endsWith("." + it)) && (leerFichero(file, palabra, config))) {
								listaencuentra.add(file.toString());
							}
						});
					}
				}
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
				return FileVisitResult.CONTINUE;
			}
		});

		return listaencuentra;
	}

	private boolean verificaExcludes(Path file, List<String> exclude) {
		List<String> filtrado = exclude.stream().filter(it -> file.toString().endsWith("." + it))
				.collect(Collectors.toList());
		return filtrado.isEmpty();
	}

	private boolean leerFichero(Path fichero, String cadena, boolean[] config) {
		try (BufferedReader file = new BufferedReader(new FileReader(fichero.toFile()))) {
			String slinea;
			while ((slinea = file.readLine()) != null) {
				if (config[0]) {
					if (slinea.contains(cadena)) {
						return true;
					}
				} else if (config[1]) {
					if (slinea.toLowerCase().contains(cadena)) {
						return true;
					}
				} else {
					if (slinea.toUpperCase().contains(cadena)) {
						return true;
					}
				}
			}
		} catch (IOException ex) {
			FxDialogs.showException(ERROR, ex.getMessage(), ex);
		}
		return false;
	}

	public String getDetalles(String palabra, File file, boolean[] config) {
		return (String) getPosiciones(palabra, file, config, false, false);
	}

	@SuppressWarnings("unchecked")
	public List<String> getDetallesFindCadena(String palabra, File file, boolean[] config) {
		String traza = (String) getPosiciones(palabra, file, config, true, false);
		if (!traza.isEmpty()) {
			SeparateTraza separaTraza = new SeparateTraza(traza);
			String idTraza = separaTraza.get();
			if (!idTraza.isEmpty())
				return (List<String>) getPosiciones(idTraza, file, config, false, true);
		}
		return new ArrayList<>();
	}

	private Object getPosiciones(String cadena, File fichero, boolean[] config, boolean isLog, boolean notpage) {
		StringBuilder stringbuilder = new StringBuilder();
		List<Integer> lineas = new ArrayList<>();
		List<String> parrafo = new ArrayList<>();
		try (BufferedReader file = new BufferedReader(new FileReader(fichero))) {
			String slinea;
			int linea = 0;
			while ((slinea = file.readLine()) != null) {
				linea++;
				if (hasLine(config, slinea, cadena)) {
					lineas.add(linea);
					parrafo.add(slinea);
				}
			}
		} catch (IOException ex) {
			FxDialogs.showException(ERROR, ex.getMessage(), ex);
		}
		if (isLog && !lineas.isEmpty()) {
			stringbuilder.append(parrafo.get(0));
		} else {
			if (notpage) {
				return parrafo;
			}
			getBody(lineas, parrafo, stringbuilder);
		}
		return stringbuilder.toString();
	}

	private StringBuilder getBody(List<Integer> lineas, List<String> parrafo, StringBuilder stringbuilder) {
		contador = 0;
		lineas.forEach(it -> {
			stringbuilder.append("Linea: ").append(it).append(" \"").append(parrafo.get(contador)).append("\"")
					.append("\n");
			contador++;
		});
		return stringbuilder;
	}

	private boolean hasLine(boolean[] config, String slinea, String cadena) {
		if (config[0]) {
			return slinea.contains(cadena);
		} else if (config[1]) {
			return slinea.toLowerCase().contains(cadena);
		} else {
			return slinea.toUpperCase().contains(cadena);
		}
	}
}
