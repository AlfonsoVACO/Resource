/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.foreach.controllers;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import com.mycompany.foreach.utils.Console;
import com.mycompany.foreach.utils.FxDialogs;
import com.mycompany.foreach.utils.actions.Walking;
import com.mycompany.foreach.utils.constantes.Constantes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.stage.DirectoryChooser;

/**
 * FXML Controller class
 *
 * @author 6_Delta
 */
public class FindwordController implements Initializable {

	@FXML
	private ListView<String> paths;
	@FXML
	private ListView<String> extensiones;
	@FXML
	private Button btnExt;
	@FXML
	private Button btnexcludesExt;
	@FXML
	private Button btnexcludesMore;
	@FXML
	private TextField path;
	@FXML
	private TextField strinput;
	private ObservableList<String> itemspath;
	private ObservableList<String> itemsextends;
	private boolean[] radios = new boolean[3];

	private List<String> excludes;

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		this.itemsextends = FXCollections.observableArrayList();
		this.excludes = new ArrayList<>();
		btnexcludesExt.setVisible(false);
		btnexcludesMore.setVisible(false);
	}

	@FXML
	private void executecomands(KeyEvent event) {
		KeyCombination commandOpen = new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN);
		KeyCombination commandDetails = new KeyCodeCombination(KeyCode.D, KeyCombination.CONTROL_DOWN);
		String value = paths.getSelectionModel().getSelectedItems().get(0);
		if (value != null && !value.isEmpty()) {
			if (commandOpen.match(event)) {
				Console.execute("cmd", "/c", "\"" + value + "\"");
				if (!Console.getLog().equals("")) {
					FxDialogs.showError(Constantes.TITLE, Console.getLog());
				}
			}
			if (commandDetails.match(event)) {
				Walking walking = new Walking();
				String detalles = walking.getDetalles(this.strinput.getText(), new File(value), this.radios);
				FxDialogs.showInformation("Detalles", detalles);
			}
		} else {
			FxDialogs.showError("Index", "No se seleccionó ningún resultado");
		}
	}

	@FXML
	private void examinar(ActionEvent event) {
		DirectoryChooser directory = new DirectoryChooser();
		directory.setTitle("Agregar path");
		File archivo = directory.showDialog(null);
		if (archivo != null) {
			this.path.setText(archivo.getPath());
		}
	}

	@FXML
	private void buscar(ActionEvent event) throws IOException {
		this.paths.setItems(FXCollections.observableArrayList());
		String palabra = this.strinput.getText();
		this.itemspath = FXCollections.observableArrayList();
		String url = this.path.getText();

		if (!"".equals(url)) {
			if (this.itemsextends.isEmpty()) {
				FxDialogs.showError(Constantes.TITLE, "No has agregado las extenciones a buscar");
			} else if ("".equals(palabra)) {
				FxDialogs.showError(Constantes.TITLE, "Olvidaste agregar el texto a buscar");
			} else {
				executeFindWord(palabra, url);
			}
		} else {
			FxDialogs.showWarning(Constantes.TITLE, "No has seleccionado una ruta");
		}
	}

	private void executeFindWord(String palabra, String url) throws IOException {
		Walking lector = new Walking();
		List<String> loistaarchivos = null;
		boolean extep = this.itemsextends.filtered(it -> ("mp3".equals(it)) || ("mp4".equals(it)) || ("jpg".equals(it))
				|| ("png".equals(it)) || ("pdf".equals(it))).isEmpty();
		if (extep) {
			if (!notTrue())
				this.radios[0] = true;
			loistaarchivos = lector.execute(palabra, this.itemsextends, Paths.get(url), this.radios, this.excludes);
			if (loistaarchivos.isEmpty()) {
				FxDialogs.showInformation(Constantes.TITLE, "Ups! ningún archivo encontrado");
			} else {
				loistaarchivos.forEach(it -> this.itemspath.add(it));
				this.paths.setItems(this.itemspath);
			}
		} else {
			FxDialogs.showWarning(Constantes.TITLE, "Ups! hay extenciones que no se pueden leer");
		}
	}

	@FXML
	private void addExt(ActionEvent event) {
		String extension = FxDialogs.showTextInput("Agrega extensión", "Ingresa la extencióna a agregar", "");
		if (extension != null && !extension.isEmpty()) {
			if (extension.trim().equals("*")) {
				String opcion = FxDialogs.showConfirm("Extenciones", "Desea agregar un rex \"xlx|dd|ext\"", FxDialogs.YES,
						FxDialogs.NO);
				if (opcion.equals(FxDialogs.YES)) {
					String extensionArr = FxDialogs.showTextInput("Agrega extensiones",
							"Agrega extenciones separadas por | sin el punto", "");
					if (!extensionArr.isEmpty())
						desglosaRex(extensionArr, extension);
				} else {
					excludeExt(extension);
				}
				if (!this.excludes.isEmpty()) {
					btnexcludesExt.setVisible(true);
					btnexcludesMore.setVisible(true);
				}
			} else {
				itemsextends.add(extension);
				extensiones.setItems(itemsextends);
			}
		}
	}

	private void desglosaRex(String rex, String extension) {
		itemsextends.add(extension);
		extensiones.setItems(itemsextends);
		btnExt.setDisable(true);
		this.excludes.addAll(Arrays.asList(rex.split("\\|")));
	}

	private void excludeExt(String extension) {
		itemsextends.add(extension);
		extensiones.setItems(itemsextends);
		btnExt.setDisable(true);
		rellenoExclude();
	}

	private void rellenoExclude() {
		boolean moreExt = true;
		do {
			String opcion = FxDialogs.showConfirm("Extenciones", "Desea agregar una extención a excluir", FxDialogs.YES,
					FxDialogs.NO);
			if (opcion.equals(FxDialogs.YES)) {
				String excludeExtension = FxDialogs.showTextInput("Agrega extensión", "Ingresa la extencióna a agregar",
						"");
				if (excludeExtension != null && !excludeExtension.isEmpty()) {
					this.excludes.add(excludeExtension);
				}
			} else {
				moreExt = false;
			}
		} while (moreExt);
	}

	@FXML
	private void clean(ActionEvent event) {
		this.itemsextends.clear();
		this.itemspath.clear();
		this.extensiones.setItems(FXCollections.observableArrayList());
		btnExt.setDisable(false);
		btnexcludesExt.setVisible(false);
		btnexcludesMore.setVisible(false);
	}

	@FXML
	private void avanzado(ActionEvent event) {
		this.radios = FxDialogs.getRadioDes(Constantes.TITLE, "Opciones avanzadas",
				new RadioButton("Mayusculas y minusculas"), new RadioButton("Solo minusculas"),
				new RadioButton("Solo mayusculas"));
	}

	@FXML
	private void excludesExt(ActionEvent event) {
		FxDialogs.showLongMessage("Excluidas", "Lista de extenciones excluidas", this.excludes);
	}

	@FXML
	private void excludesMore(ActionEvent event) {
		rellenoExclude();
	}

	private boolean notTrue() {
		for (boolean item : this.radios) {
			if (item)
				return true;
		}
		return false;
	}

}
