package com.mycompany.foreach.controllers;

import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.ResourceBundle;

import com.mycompany.foreach.annotation.Obligatorios;
import com.mycompany.foreach.daos.ConsultaCurpDao;
import com.mycompany.foreach.models.CurpRequestTO;
import com.mycompany.foreach.models.seguridad.SeguridadResponse;
import com.mycompany.foreach.utils.Encrypt;
import com.mycompany.foreach.utils.FxDialogs;
import com.mycompany.foreach.utils.HttpUtils;
import com.mycompany.foreach.utils.Util;
import com.mycompany.foreach.utils.UtilValidacion;
import com.mycompany.foreach.utils.UtileriasServicio;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class OPTController implements Initializable {

	@FXML
	@Obligatorios(mensajeError = "El campo URL es necesario para la operación")
	private TextField url;
	@FXML
	@Obligatorios(mensajeError = "El campo X-Aplicacion es necesario para la operación")
	private TextField xaplicacion;
	@FXML
	@Obligatorios(mensajeError = "Tu request es necesario para la operación")
	private TextArea respuestaJSON;
	@FXML
	private Button request;

	private String requestOriginal = "";

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		request.setDisable(true);
	}

	@FXML
	private void ejecutar(ActionEvent event) throws KeyManagementException, NoSuchAlgorithmException {
		validaCampos();
		if (Util.isJSONValid(respuestaJSON.getText())) {
			testCurp();
			bloqueaBotonyDatos();
			this.requestOriginal = respuestaJSON.getText();
			enviarPeticion();
		} else {
			FxDialogs.showError("Request", "No es un JSON válido");
		}
	}

	private void testCurp() {
		ConsultaCurpDao consulta = new ConsultaCurpDao();
		CurpRequestTO curp = new CurpRequestTO();
		curp.setCurp("TOVE920802HDFRZV08");
		consulta.ejecutaServicio360(curp);
	}

	private void enviarPeticion() throws KeyManagementException, NoSuchAlgorithmException {
		HttpUtils utilhttp = new HttpUtils(url.getText(), xaplicacion.getText());
		String resultado = utilhttp.examplePost();
		SeguridadResponse seguridad = UtileriasServicio.jsonAObjeto(resultado, SeguridadResponse.class);
		Encrypt<Object> encriptado = new Encrypt<>();
		Map<String, Object> mapaSalida = encriptado.get(respuestaJSON.getText(),
				seguridad.getResultado().getAccesoPublico());
		mapaSalida.put("idAcceso", seguridad.getResultado().getIdAcceso());
		mapaSalida.put("accesoPublico", seguridad.getResultado().getAccesoPublico());
		mapaSalida.put("accesoPrivado", seguridad.getResultado().getAccesoPrivado());
		mapaSalida.put("aplicacion", seguridad);
		request.setDisable(false);
		respuestaJSON.setText(UtileriasServicio.objetoAJson(mapaSalida));
	}

	private void bloqueaBotonyDatos() {
		if (this.requestOriginal.isEmpty())
			request.setDisable(true);
		this.requestOriginal = "";
	}

	@FXML
	private void request(ActionEvent event) {
		FxDialogs.showInformation("Request", this.requestOriginal);
	}

	private void validaCampos() {
		UtilValidacion utilvalid = new UtilValidacion(this, false);
		utilvalid.validarRequest();
	}

}
